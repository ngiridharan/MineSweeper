#include <SFML/Graphics.hpp>
#include "GameManager.h"

int main()
{
    GameManager newGame;
    newGame.Run();
    return 0;
}













